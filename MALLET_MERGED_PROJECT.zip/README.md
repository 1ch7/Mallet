
# MALLET - Integrated Frontend + PHP Backend

This package merges the React/Vite frontend with the PHP backend.

## Structure

- `/src` → React frontend
- `/backend` → PHP backend and APIs

## Features Connected

### Wallet Analysis
The React frontend now calls:

`/backend/api/wallet_analysis.php`

The account checker page is fully connected to the PHP backend.

### GitHub Verification
The PHP GitHub verification flow remains available at:

`/backend/linkAccount.php`

## How To Run

### 1. Install frontend dependencies

```bash
npm install
```

### 2. Start PHP server

From the `backend` folder:

```bash
php -S localhost:8000
```

### 3. Start React frontend

```bash
npm run dev
```

### 4. Configure proxy (optional)

If your PHP server is running on port 8000, update the fetch target in:

`src/app/components/AccountResults.tsx`

Example:

```ts
fetch('http://localhost:8000/api/wallet_analysis.php')
```

## Demo Wallets

Try these addresses:

- `0x742d35Cc6634C0532925a3b844Bc9e7595f0b6f0`
- `0x4951b1018033954f02e96ec9b7375336b5f7b6da`
- `0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045`
