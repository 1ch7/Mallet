
import { useEffect, useState } from 'react';
import { AlertTriangle, Shield, TrendingUp, Calendar, Activity, Wallet, Loader2 } from 'lucide-react';

interface AccountResultsProps {
  walletAddress: string;
}

interface WalletData {
  success: boolean;
  address: string;
  creation_date: string;
  total_transactions_6months: number;
  flagged_interactions: Record<string, number>;
  total_flagged_count: number;
  analyzed_transactions: number;
  last_transaction: string | null;
  error?: string;
}

export function AccountResults({ walletAddress }: AccountResultsProps) {
  const [data, setData] = useState<WalletData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchWalletData = async () => {
      setLoading(true);
      setError('');

      try {
        const formData = new FormData();
        formData.append('address', walletAddress);

        const response = await fetch('/backend/api/wallet_analysis.php', {
          method: 'POST',
          body: formData,
        });

        const result = await response.json();

        if (!result.success) {
          setError(result.error || 'Failed to analyze wallet');
        } else {
          setData(result);
        }
      } catch (err) {
        setError('Unable to connect to PHP backend. Make sure Apache/PHP is running.');
      } finally {
        setLoading(false);
      }
    };

    fetchWalletData();
  }, [walletAddress]);

  if (loading) {
    return (
      <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 p-8">
        <div className="flex items-center justify-center gap-3 text-white">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span>Analyzing wallet...</span>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="bg-red-500/10 backdrop-blur-lg rounded-2xl border border-red-500/30 p-6">
        <div className="flex items-center gap-3 text-red-200">
          <AlertTriangle className="w-6 h-6" />
          <div>
            <p className="font-semibold">Analysis Failed</p>
            <p className="text-sm">{error}</p>
          </div>
        </div>
      </div>
    );
  }

  const daysOld = Math.floor(
    (Date.now() - new Date(data.creation_date).getTime()) / (1000 * 60 * 60 * 24)
  );

  const status =
    data.total_flagged_count === 0
      ? 'Safe'
      : data.total_flagged_count < 10
      ? 'Suspicious'
      : 'Malicious';

  const statusConfig = {
    Safe: { color: 'bg-green-500', textColor: 'text-green-200' },
    Suspicious: { color: 'bg-yellow-500', textColor: 'text-yellow-200' },
    Malicious: { color: 'bg-red-500', textColor: 'text-red-200' },
  };

  const currentStatus = statusConfig[status];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl border border-white/20 overflow-hidden">
      <div className="p-6 space-y-6">
        <div className="grid md:grid-cols-2 gap-4">
          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <p className="text-blue-200 text-sm mb-2">Wallet ID</p>
            <p className="text-white font-mono text-sm break-all">{data.address}</p>
          </div>

          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <p className="text-blue-200 text-sm mb-2">Status</p>
            <span className={`${currentStatus.color} ${currentStatus.textColor} px-3 py-1 rounded-full text-sm font-semibold inline-flex items-center gap-2`}>
              <Shield className="w-4 h-4" />
              {status}
            </span>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-blue-400" />
              <p className="text-blue-200 text-sm">Wallet Age</p>
            </div>
            <p className="text-white font-semibold">{daysOld} days</p>
          </div>

          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <p className="text-blue-200 text-sm">Last Transaction</p>
            </div>
            <p className="text-white font-semibold">
              {data.last_transaction
                ? new Date(data.last_transaction).toLocaleDateString()
                : 'No transactions'}
            </p>
          </div>

          <div className="bg-black/40 rounded-xl p-4 border border-white/10">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              <p className="text-blue-200 text-sm">6 Month Activity</p>
            </div>
            <p className="text-white font-semibold">
              {data.total_transactions_6months} transactions
            </p>
          </div>
        </div>

        <div className="bg-black/40 rounded-xl p-5 border border-white/10">
          <div className="flex items-center gap-2 mb-4">
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            <h3 className="text-lg font-semibold text-white">Flagged Interactions</h3>
          </div>

          {Object.keys(data.flagged_interactions || {}).length === 0 ? (
            <p className="text-green-200">No flagged wallet interactions detected.</p>
          ) : (
            <div className="space-y-3">
              {Object.entries(data.flagged_interactions).map(([address, count]) => (
                <div
                  key={address}
                  className="flex items-center justify-between bg-red-500/10 border border-red-500/20 rounded-lg p-3"
                >
                  <p className="text-white font-mono text-sm">{address}</p>
                  <span className="text-red-200 text-sm">{count} interactions</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
